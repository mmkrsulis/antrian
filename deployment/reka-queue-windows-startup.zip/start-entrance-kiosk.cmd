@echo off
setlocal
set "QUEUE_URL=http://100.64.131.49:8090/kiosk?directprint=1"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "AGENT=%~dp0RekaThermalPrintAgent.exe"

start "Reka Thermal Print Agent" /min "%AGENT%"

:wait_server
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 '%QUEUE_URL%'; exit ([int]($r.StatusCode -ne 200)) } catch { exit 1 }"
if errorlevel 1 (
  timeout /t 5 /nobreak >nul
  goto wait_server
)

set "KIOSK_PROFILE=%LOCALAPPDATA%\RekaQueue\KioskProfile"
start "Entrance Kiosk" "%EDGE%" --user-data-dir="%KIOSK_PROFILE%" --kiosk "%QUEUE_URL%" --edge-kiosk-type=fullscreen --kiosk-printing --disable-print-preview --no-first-run --no-default-browser-check --disable-session-crashed-bubble
endlocal
